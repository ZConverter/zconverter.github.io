#### v4.0.0

ZDM-API 4.0.0 과 함께 나오는 릴리스입니다. **CLI 의 명령 · 필수 옵션 · 종료 코드 체계는 v3.0.1 과 같습니다.** 새 옵션은 `backup image list --strict` 하나입니다.

CLI v4.0.0 은 구버전 API 와도 동작합니다. 아래 "API 4.0.0 에 따른 표시 변화" 는 CLI 버전과 무관하게 **API 를 4.0.0 으로 올리면** 나타납니다.

---

**신규 — `backup image list` 의 부분 스캔 표시**

이미지 조회는 저장소마다 실시간 스캔을 합니다. 일부 저장소를 스캔하지 못하면 목록에서 그 저장소의 이미지가 빠지는데, 지금까지는 이 사실이 화면에 나오지 않았습니다.

이제 text · table 형식에서 **표준에러**에 요약과 저장소별 사유를 냅니다. 결과(표준출력)와 `--names-only` 한 줄 출력은 그대로라 파이프 사용에 영향이 없습니다.

```
[Scan] 4 of 6 repositories scanned (2 failed)
  - center zdm-a, repository 11: not scanned, the server's scan time budget ran out (retryable)
  - center zdm-a, repository 12: Image polling timed out (JOB-ERROR-68, retryable)
```

- `retryable` 이 붙은 저장소는 다시 조회하면 나올 수 있습니다. `--repository-id` 로 그 저장소만 다시 조회하면 빠릅니다.
- `--output json` 은 응답의 `scan`(`total` · `succeeded` · `failed` · `failures[]`)이 결과에 그대로 실려 있으므로 따로 출력하지 않습니다.

---

**신규 — `backup image list --strict`**

일부 저장소를 스캔하지 못하면 **결과를 출력하지 않고 실패로 끝냅니다.** 불완전한 목록으로 다음 단계를 진행하면 안 되는 스크립트에서 씁니다. 기본값은 꺼져 있으며, 끄면 종전처럼 부분 결과를 성공으로 처리합니다.

```bash
zdm-cli backup image list --server web01 --names-only --strict
```

- 종료 코드 `1`, 오류 코드 `PARTIAL_SCAN`, 메시지 `Incomplete scan: N of M repositories scanned (F failed)`.
- `--output json` 이면 표준에러의 실패 응답에 `error.code: "PARTIAL_SCAN"` 과 `error.details.scan`(스캔 결과)이 실립니다.

자세한 옵션은 [backup image list](/zdm/ko/cli/4.0.0/docs/backup/image-list) 참조.

---

**API 4.0.0 에 따른 표시 변화**

아래는 CLI 가 서버 응답 값을 그대로 표시하기 때문에 생기는 변화입니다.

**하위 호환 불가 — `replication` · `os-replication` 목록의 상태 표시값이 바뀝니다**

`replication list` · `os-replication list` 의 상태(`status(current)` · `status`) 값이 `--status` 필터와 같은 어휘로 통일됩니다. backup · recovery 와 같은 규칙입니다.

| 종전 | 이후 |
|---|---|
| `Waiting` | `Registered` (스케줄이 있으면 `Scheduled`) |
| `Start` · `PROCESSING` | `Processing` (준비 중이면 `Preparing`, 취소 중이면 `Canceling`) |
| 실패로 끝난 `Complete` | `Error` |
| `Cancel` | `Canceled` |
| `Schedule` | `Scheduled` |

- **이 값으로 분기하던 스크립트는 새 값으로 바꿔야 합니다.** `--output json` 의 `job.info.status.current` 도 같이 바뀝니다.
- `--status canceled` 가 취소된 작업을 고르고, `--status registered` 는 취소된 작업을 더 이상 고르지 않습니다.
- `replication update` 결과의 `[Changed Fields]` 에서 status 는 `Registered -> start` 처럼 이전 값은 계산 상태, 새 값은 요청한 값으로 나옵니다.
- `replication monit` 의 상태는 종전에도 이 어휘였으므로 바뀌지 않습니다.

**동작 변경 — `recovery list` 의 정렬**

`--asc` 가 이제 실제로 오름차순(시작 시각 기준)으로 정렬합니다. 종전에는 서버가 정렬 요청을 무시해 `--asc` 를 줘도 순서가 같았습니다. `--asc` 를 주지 않으면 최신 작업이 먼저 나옵니다. 결과 순서에 기대던 스크립트는 확인이 필요합니다.

**동작 변경 — 단건 조회에 `--status` 를 함께 주면**

`replication list --id 7 --status processing` 처럼 단건 조회에 상태 필터를 붙였는데 작업 상태가 다르면, 이제 "작업은 있으나 조건에 맞는 결과가 없다" 는 메시지와 함께 종료 코드 `2` 로 끝납니다.

**표시 변경 — `recovery list` 의 대상 파티션**

복구 대상 파티션을 찾지 못한 경우 상세의 `to` 가 원본 드라이브 대신 `Unknown` 으로 나옵니다. 종전 값은 원본 쪽 값이어서 틀린 정보였습니다.

---

**표시 변경 — cloud-auth**

- `cloud-auth recovery-list`: 서버가 평문 자격증명을 더 이상 돌려주지 않으므로 text 출력에서 `accessKey` · `serviceAccount` 줄을 뺐습니다. 자격증명은 등록할 때만 보냅니다.
- `cloud-auth zos-list` · `zos-regist`: 서버 내부 경로(`filePath`)를 더 이상 표시하지 않습니다. 파일명(`fileName`)은 그대로이고 `zos-download` 도 종전대로 동작합니다.
- **수정 — `cloud-auth recovery-list` 가 region · displayRegion · project 를 표시하지 않던 문제.** 이제 text 에 `region` · `displayRegion`(GCP 는 `project` 포함)이 나오고, table 의 `region` · `displayRegion` 열에 실제 값이 채워집니다.
- **수정 — `cloud-auth zos-list` 의 생성일이 늘 `-` 로 나오던 문제.** 이제 실제 생성일이 나오며, text 키와 table 열 이름이 `createDate` → `createdDate` 로 바뀝니다. 이 이름으로 출력을 읽던 스크립트는 바꿔야 합니다.

---

**배포 파일에 릴리스 노트 동봉**

다운로드한 압축 파일에 이 문서와 같은 내용의 `RELEASE_NOTES.md` 가 실행 파일 · 설정 파일 옆에 함께 들어 있습니다. 설정 파일(`zdm-cli-config.json`)은 v3.0.1 과 같은 빈 기본 양식입니다.
