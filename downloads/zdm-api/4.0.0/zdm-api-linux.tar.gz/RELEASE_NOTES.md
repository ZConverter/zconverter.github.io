#### v4.0.0

replication · os-replication 의 상태 값을 backup · recovery 와 같은 어휘로 통일했습니다. cloud-auth 조회 응답에서 자격증명과 서버 경로를 뺐고, 그동안 받기만 하고 적용하지 않던 요청 파라미터를 실제로 적용합니다. 이 밖에 recovery · backup · cloud-auth · license 의 버그를 고쳤습니다.

> **연동 시 확인** — 아래 **하위 호환 불가** 항목은 v3.0.1 과 응답 값이나 결과가 다릅니다. 해당 필드나 파라미터를 쓰는 연동 코드는 각 항목의 대응 방법을 확인하세요.

> **설치 · 업그레이드 시 확인** — 새로 설치한다면 `env/.env.production` 의 `DB_PASSWORD` 를 채워야 서버가 시작됩니다. 업그레이드할 때는 기존 env 파일을 그대로 두세요. 자세한 내용은 아래 "보안 — 배포 파일의 설정 값" 항목을 참조하세요.

---

**하위 호환 불가 — replication · os-replication 조회의 상태 값 어휘 변경**

- 대상: `GET /replications` · `GET /replications/:identifier` · `GET /os-replications` · `GET /os-replications/:identifier` 응답의 `job.info.status.current`. V1 · V2 모두 해당합니다.
- 변경 전에는 `Waiting` · `Start` · `PROCESSING` · `Cancel` · `Schedule` 같은 값이 나갔습니다. 이제 `?status=` 필터와 같은 값인 `Preparing` · `Processing` · `Complete` · `Scheduled` · `Registered` · `Canceling` · `Canceled` · `Error` 가 나갑니다. backup · recovery 조회와 같은 어휘입니다.
- 진행 중인 작업은 실제 진행 단계가 반영됩니다. 실패로 끝난 작업은 `Complete` 대신 `Error`, 취소된 작업은 `Canceled`, 스케줄 대기 작업은 `Scheduled` 입니다.
- 목록의 `?status=preparing` · `?status=canceling` 이 이제 해당 작업을 찾습니다. 종전에는 늘 빈 결과였습니다. 취소된 작업은 `?status=canceled` 로 찾습니다.
- 대응: `status.current` 를 옛 값과 비교하던 코드는 새 값으로 바꾸세요. 대소문자를 무시하고 비교하기를 권장합니다. 필터로 보내는 값과 응답 값이 이제 같습니다.

**하위 호환 불가 — replication · os-replication 수정 응답의 `status` 항목**

- 대상: `PUT /replications/:identifier` · `PUT /os-replications/:identifier` 응답 `summary.updatedFields[]` 의 `status` 항목.
- `previous` 는 조회 응답 `status.current` 와 같은 상태 값이고, `new` 는 요청 body 의 `status` 값(`start` · `stop`) 그대로입니다. backup · recovery 수정 응답과 같은 규칙입니다.
- 예: `{ "previous": "Waiting", "new": "Start" }` → `{ "previous": "Registered", "new": "start" }`
- 대응: 이 항목을 비교하거나 표시하던 코드는 `previous` 를 조회 상태 값으로, `new` 를 소문자 요청 값으로 해석하세요.

**하위 호환 불가 — replication · os-replication 단건 조회에 `status` 적용**

- 대상: `GET /replications/:identifier` · `GET /os-replications/:identifier`
- `?status=` 를 보내면 이제 적용합니다. 작업은 있는데 상태가 다르면 **404 `NOT_FOUND`** 를 반환하고, 메시지에 `exists, but no results match the specified filter conditions` 가 들어갑니다. 종전에는 이 파라미터를 무시하고 200 을 반환했습니다.
- 작업이 없을 때의 404 는 그대로입니다.
- 대응: 단건 조회에 `status` 를 붙여 보내던 호출은 빼세요. 필터 불일치와 작업 없음은 메시지로 구분할 수 있습니다.

**하위 호환 불가 — replication · os-replication 작업 모니터링의 로그 페이지 나누기**

- 대상: `GET /replications/monitoring/job/:identifier` · `GET /os-replications/monitoring/job/:identifier`
- 받기만 하고 쓰지 않던 `page` · `limit` · `sort` 를 `job.log` 에 적용합니다. `sort` 는 로그 순서 기준이며 기본값은 `desc` 입니다.
- `page` · `limit` 을 모두 생략하면 종전처럼 10줄만 반환합니다(기본 `desc` 이므로 최근 10줄). `page` · `limit` 중 하나라도 보내면 기본 `page=1` · `limit=20` 으로 나누고, 응답에 `data.pagination` 을 함께 보냅니다. 범위를 벗어난 `page` 는 빈 `log` 와 함께 200 입니다.
- 대응: 의미 없이 이 파라미터를 보내던 호출은 빼면 종전과 같은 응답을 받습니다. 로그를 나눠 받으려면 `data.pagination.totalItems` · `hasNextPage` 를 사용하세요.

**하위 호환 불가 — replication(V1) 수정이 `schedule` 을 반영**

- 대상: 서버가 V1 스키마일 때의 `PUT /replications/:identifier`
- body 의 `schedule` 을 이제 저장합니다. 종전에는 200 을 반환하면서 값을 버렸습니다. 숫자는 기존 schedule 을 참조하며 없는 ID 면 오류이고, 객체는 schedule 을 새로 만들거나 고칩니다. 실제로 바뀌면 `updatedFields` 에 `schedule` 항목이 추가됩니다.
- 대응: V1 수정 body 에 `schedule` 을 담아 보내던 호출은 그 값이 이제 적용된다는 점을 확인하세요. 바꿀 생각이 없다면 빼고 보내세요.

**하위 호환 불가 — recovery 수정 · 조회 정정**

- `PUT /recoveries/:identifier` — ID 로 지정해도 요청의 `center` 와 작업이 속한 center 를 대조합니다(backup 과 같은 방식). 다르면 **404 `JOB-ERROR-01`** 입니다. 종전에는 다른 center 의 작업이 그대로 수정됐습니다. 작업이 속한 center 는 `GET /recoveries/:identifier` 로 확인하세요.
- `PUT /recoveries/:identifier` — 이름 변경 중 예기치 않은 오류가 나면 종전의 404 `JOB-ERROR-08` 대신 **500 `INTERNAL_SERVER_ERROR`** 를 반환합니다. 같은 이름이 이미 있을 때의 409 는 그대로입니다. `JOB-ERROR-08` 을 "대상 없음"으로 처리하던 코드는 500 을 서버 오류로 처리하세요.
- `GET /recoveries` · `GET /recoveries/:identifier` — 복구 대상 파티션을 찾지 못하면 `job.detail[].to` 가 원본 드라이브 대신 `"Unknown"` 입니다. 원본 드라이브는 `from` 을 읽으세요.
- `GET /recoveries` — `sort` 를 이제 작업 시작 시각 기준으로 적용합니다. 생략하면 `desc` 입니다. 아직 시작하지 않은 작업은 `asc` 에서 맨 앞, `desc` 에서 맨 뒤에 옵니다. `sort` 를 보내지 않아도 목록 순서와 페이지 경계가 종전과 달라지므로, 필요한 순서는 `sort` 로 명시하세요.

**하위 호환 불가 — cloud-auth 조회 응답에서 자격증명과 서버 경로 제거**

- `GET /cloud-auth/recovery` — AWS 항목의 `accessKey` · `secretKey`, GCP 항목의 `serviceAccount` · `serviceKeyFilePath` 를 응답에서 뺐습니다. 등록한 자격증명이 조회 응답에 평문으로 실려 나가던 문제입니다. GCP 키 파일 이름은 `serviceKeyFile` 로 계속 나갑니다.
- `GET /cloud-auth/zos` 항목과 ZOS 등록 응답의 `cloudInfo` 에서 서버 저장 경로 `filePath` 를 뺐습니다. 파일 이름은 `fileName` 으로 계속 나갑니다.
- 등록 요청 방식과 ZOS 파일 내려받기(`GET /cloud-auth/zos/download/:fileName`)는 그대로입니다.
- 대응: 이 필드를 읽던 코드는 `fileName` · `serviceKeyFile` 을 사용하세요. 자격증명이 필요하면 등록한 쪽에서 따로 보관하세요.

---

**Bugfix — backup 등록 · 수정에서 기존 schedule ID 지정 시 실패**

- `POST /backups` · `PUT /backups/:identifier` — 기존 schedule ID(숫자)를 지정하면 모든 파티션이 `Duplicate data exists` 로 실패하던 문제를 고쳤습니다. 요청 · 응답 형식은 같습니다.

**Bugfix — recovery 수정 · 삭제**

- `PUT /recoveries/:identifier` — 숫자 schedule ID 를 지정하면 응답은 변경됐다고 하지만 실제 schedule 은 그대로이던 문제를 고쳤습니다.
- `PUT /recoveries/:identifier` — 수정할 때 요청과 관계없는 값까지 다시 써서, 그 사이 바뀐 작업 상태가 되돌아갈 수 있던 문제를 고쳤습니다. 요청한 항목만 저장합니다.
- `DELETE /recoveries/:identifier` — ID 로 삭제할 때 `center` 를 주지 않으면 다른 center 에 있는 같은 이름 작업의 이력 · 로그까지 지워지던 문제를 고쳤습니다. 응답 형식은 같습니다.
- `DELETE /recoveries/:identifier` — 응답 `jobInfo[].partition` 에 같은 파티션이 반복 표기되던 문제(`"/boot, /boot"`)를 고쳤습니다.
- `POST /recoveries` · `POST /recoveries/image` — 모니터링 `details[].diskNumber`(Windows)가 복구 대상이 아닌 원본 디스크 번호를 보이던 문제를 고쳤습니다. 새로 등록한 작업부터 적용되며, 이미 등록된 작업의 값은 그대로입니다.
- `GET /recoveries` — 서버 정보가 다른 center 의 같은 이름 서버로 채워질 수 있던 문제를 고쳤습니다.

**Bugfix — 같은 이름 · 같은 키의 동시 요청**

- backup · recovery 등록과 이름 변경에서, 다른 center 의 같은 이름 요청이 동시에 들어와도 차례로 처리해 같은 이름 작업이 두 건 생기지 않습니다. 기다림이 길어지면 **409 `CONFLICT`** 가 나갈 수 있습니다.
- backup · recovery 수정에서 현재 이름과 같은 `changeName` 을 보내면 종전의 409 `JOB-ERROR-07` 대신 200 으로 성공합니다. 다른 작업이 쓰는 이름은 그대로 409 입니다.
- `POST /licenses` — 같은 키를 동시에 등록해도 한 건만 등록됩니다. 뒤 요청은 409 `LICENSE-ERROR-11`, 기다림이 길어지면 409 `CONFLICT` 입니다.

**Bugfix — 수정 요청의 대문자 값 거부**

- backup · recovery · replication · os-replication 수정 body 의 선택형 값(`"START"` · `"OCI"` 등)을 대문자로 보내면 400 이던 문제를 고쳤습니다. 조회 파라미터처럼 대소문자를 구분하지 않습니다.

**Bugfix — cloud-auth**

- `GET /cloud-auth/recovery?cloudType=aws` (또는 `gcp`) 가 등록된 항목이 있어도 늘 0건이던 문제를 고쳤습니다.
- `GET /cloud-auth/recovery` · `GET /cloud-auth/zos` 를 필터 없이 조회해도 최신 등록순으로 정렬합니다.
- `DELETE /cloud-auth/zos/:identifier` — 파일 이름으로 지울 때 같은 이름의 항목이 여럿이면 임의의 한 건을 지우던 동작을, 아무것도 지우지 않고 **409 `CONFLICT`** 로 바꿨습니다. 메시지에 해당 ID 가 나열되니 ID 로 다시 삭제하세요. 한 건이면 종전처럼 삭제합니다.
- `DELETE /cloud-auth/zos/:identifier` — `center` 를 주면 그 center 안에서만 파일 이름을 찾습니다. 다른 center 에 같은 이름이 있어도 삭제할 수 있고, 다른 center 에만 있는 이름이면 404 입니다.

**동작 변경 — backup 이미지 조회 시간 한도**

- `GET /backups/images` · `GET /backups/images/server/:server` — 한 요청에서 동시에 조회하는 저장소 수와 전체 조회 시간에 상한을 뒀습니다. 시간이 모자라 조회하지 못한 저장소는 응답 `scan.failures[]` 에 `reason: "budget_exhausted"`, `retryable: true` 로 기록됩니다. 응답 필드는 추가 · 제거되지 않았습니다.
- 저장소가 많은 환경에서는 일부 저장소가 결과에서 빠질 수 있습니다. 서버 env `BACKUP_IMAGE_SCAN_CONCURRENCY`(기본 4) · `BACKUP_IMAGE_SCAN_TOTAL_BUDGET_MS`(기본 60000, 밀리초)로 조정할 수 있습니다.

**동작 변경 — 토큰 발급 횟수 제한 기본값 100 → 2700**

- `POST /token/issue` — IP 별 발급 시도 제한의 기본값을 **15분당 100회에서 2700회**(초당 3회)로 올렸습니다. 서버 env `RATE_LIMIT_TOKEN_MAX` 를 지정했다면 그 값이 우선합니다. 제한을 좁히려면 이 값을 낮추세요.

---

**보안 — 배포 파일의 설정 값**

- v2.0.2 · v3.0.0 · v3.0.1 배포 파일의 `env/.env.production` 에 개발 환경의 DB 비밀번호와 고정된 `JWT_SECRET` 이 들어 있었습니다. 이 버전부터는 배포 파일마다 새로 만든 설정이 실립니다. `JWT_SECRET` 은 무작위 값이고 `DB_PASSWORD` 는 비어 있습니다.
- 새로 설치: `DB_PASSWORD` 를 채운 뒤 실행하세요. 비어 있으면 서버가 시작되지 않습니다.
- 업그레이드: 기존 env 파일을 그대로 두세요. 덮어쓰면 DB 에 접속하지 못하고, `JWT_SECRET` 이 바뀌어 이미 발급한 토큰을 쓸 수 없게 됩니다.
- v2.0.2 ~ v3.0.1 배포 파일의 env 를 그대로 쓰고 있다면 `JWT_SECRET` 을 새 값으로 바꾸기를 권장합니다.

**설정 — 업로드 파일 저장 경로 기본값 통일**

- 업로드 파일 저장 경로 기본값을 `/ZConverterManager/api-files/uploads` 로 통일했습니다. env 에 `UPLOAD_FILE_SAVE_PATH` 가 있으면 그 값을 그대로 씁니다.
- 새 env 로 옮기는 v3.0.x 설치본은 기존 경로 `/ZConverterManager/api-file` 의 업로드 파일을 새 경로로 옮기세요. 옮기지 않으면 파일 목록 · 다운로드에 나오지 않습니다.

**보안 — 그 밖의 수정**

- 파일 업로드 요청에서 예기치 않은 오류가 나면 오류 원문 대신 다른 요청과 같은 `INTERNAL_SERVER_ERROR` 로 응답합니다. DB 오류의 내부 코드도 응답에 실리지 않습니다.
- cloud-auth 파일 업로드 · 내려받기에서 저장 디렉터리 밖을 가리키는 파일 이름이나 사용자 email 은 **400 `FILE-ERROR-11`** 로 거절합니다. 일반적인 이름은 종전과 같습니다.
- `SQL_LOG_VALUES=true` 로 켰을 때 SQL 디버그 로그에 자격증명 값이 평문으로 남던 문제를 고쳤습니다. 기본 설정(꺼짐)의 로그는 그대로입니다.

**배포 파일 — 릴리스 노트 동봉**

- 배포 파일 최상위에 이 버전의 릴리스 노트 `RELEASE_NOTES.md` 와 버전 번호를 담은 `VERSION` 파일이 들어 있습니다.

운영 개선 — 서버 내부 처리 정리(설정 로드 라이브러리 업데이트, 파일 경로 계산 통일, 이미지 조회 취소 처리 등). 클라이언트 영향 없음.

자세한 내용은 [Replication 조회](/zdm/ko/api/4.0.0/docs/replication/get) · [Replication 수정](/zdm/ko/api/4.0.0/docs/replication/update) · [Recovery 수정](/zdm/ko/api/4.0.0/docs/recovery/update) · [Cloud-auth Recovery 목록](/zdm/ko/api/4.0.0/docs/cloud-auth/recovery-list) · [에러 코드](/zdm/ko/api/4.0.0/docs/error-codes) 참조.
