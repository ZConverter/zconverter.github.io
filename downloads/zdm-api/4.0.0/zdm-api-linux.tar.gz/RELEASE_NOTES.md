#### v4.0.0

replication · os-replication 의 상태 값을 backup · recovery 와 같은 어휘로 통일했습니다. cloud-auth 조회 응답에서 자격증명과 서버 경로를 뺐고, 그동안 받기만 하고 적용하지 않던 요청 파라미터를 실제로 적용합니다. 이 밖에 recovery · backup · cloud-auth · license 의 버그를 고쳤습니다.

> **연동 시 확인** — 아래 **하위 호환 불가** 항목은 v3.0.1 과 응답 값이나 결과가 다릅니다. 해당 필드나 파라미터를 쓰는 연동 코드는 각 항목의 대응 방법을 확인하세요.

> **설치 · 업그레이드 시 확인** — 새로 설치한다면 `env/.env.production` 의 `DB_PASSWORD` 를 채워야 서버가 시작됩니다. 업그레이드할 때는 기존 env 파일을 그대로 두세요. 자세한 내용은 아래 "보안 — 배포 파일의 설정 값" 항목을 참조하세요.

---

**하위 호환 불가 — replication · os-replication 조회의 상태 값 어휘 변경**

- 대상: `GET /replications` · `GET /replications/:identifier` · `GET /os-replications` · `GET /os-replications/:identifier` 응답의 `job.info.status.current`. V1 · V2 모두 해당합니다.
- 변경 전에는 `Waiting` · `Start` · `PROCESSING` · `Cancel` · `Schedule` 같은 값이 나갔습니다. 이제 `?status=` 필터와 같은 값인 `Preparing` · `Processing` · `Complete` · `Scheduled` · `Registered` · `Canceling` · `Canceled` · `Error` 가 나갑니다. backup · recovery 조회와 같은 어휘입니다.
- 진행 중인 작업은 실제 진행 단계가 반영됩니다. 실패로 끝난 작업은 `Complete` 대신 `Error`, 취소된 작업은 `Canceled`, 스케줄 대기 작업은 `Scheduled` 입니다.
- 목록의 `?status=preparing` · `?status=canceling` 이 이제 해당 작업을 찾습니다. 종전에는 늘 빈 결과였습니다. 취소된 작업은 `?status=canceled` 로 찾습니다.
- 대응: `status.current` 를 옛 값과 비교하던 코드는 새 값으로 바꾸세요. 대소문자를 무시하고 비교하기를 권장합니다. 필터로 보내는 값과 응답 값이 이제 같습니다.

**하위 호환 불가 — replication · os-replication 수정 응답의 `status` 항목**

- 대상: `PUT /replications/:identifier` · `PUT /os-replications/:identifier` 응답 `summary.updatedFields[]` 의 `status` 항목.
- `previous` 는 조회 응답 `status.current` 와 같은 상태 값이고, `new` 는 요청 body 의 `status` 값(`start` · `stop`) 그대로입니다. backup · recovery 수정 응답과 같은 규칙입니다.
- 예: `{ "previous": "Waiting", "new": "Start" }` → `{ "previous": "Registered", "new": "start" }`
- 대응: 이 항목을 비교하거나 표시하던 코드는 `previous` 를 조회 상태 값으로, `new` 를 소문자 요청 값으로 해석하세요.

**하위 호환 불가 — replication · os-replication 단건 조회에 `status` 적용**

- 대상: `GET /replications/:identifier` · `GET /os-replications/:identifier`
- `?status=` 를 보내면 이제 적용합니다. 작업은 있는데 상태가 다르면 **404 `NOT_FOUND`** 를 반환하고, 메시지에 `exists, but no results match the specified filter conditions` 가 들어갑니다. 종전에는 이 파라미터를 무시하고 200 을 반환했습니다.
- 작업이 없을 때의 404 는 그대로입니다.
- 대응: 단건 조회에 `status` 를 붙여 보내던 호출은 빼세요. 필터 불일치와 작업 없음은 메시지로 구분할 수 있습니다.

**하위 호환 불가 — replication · os-replication 작업 모니터링의 로그 페이지 나누기**

- 대상: `GET /replications/monitoring/job/:identifier` · `GET /os-replications/monitoring/job/:identifier`
- 받기만 하고 쓰지 않던 `page` · `limit` · `sort` 를 `job.log` 에 적용합니다. `sort` 는 로그 순서 기준이며 기본값은 `desc` 입니다.
- `page` · `limit` 을 모두 생략하면 종전처럼 10줄만 반환합니다(기본 `desc` 이므로 최근 10줄). `page` · `limit` 중 하나라도 보내면 기본 `page=1` · `limit=20` 으로 나누고, 응답에 `data.pagination` 을 함께 보냅니다. 범위를 벗어난 `page` 는 빈 `log` 와 함께 200 입니다.
- 대응: 의미 없이 이 파라미터를 보내던 호출은 빼면 종전과 같은 응답을 받습니다. 로그를 나눠 받으려면 `data.pagination.totalItems` · `hasNextPage` 를 사용하세요.

**하위 호환 불가 — replication(V1) 수정이 `schedule` 을 반영**

- 대상: 서버가 V1 스키마일 때의 `PUT /replications/:identifier`
- body 의 `schedule` 을 이제 저장합니다. 종전에는 200 을 반환하면서 값을 버렸습니다. 숫자는 기존 schedule 을 참조하며 없는 ID 면 오류이고, 객체는 schedule 을 새로 만들거나 고칩니다. 실제로 바뀌면 `updatedFields` 에 `schedule` 항목이 추가됩니다.
- 대응: V1 수정 body 에 `schedule` 을 담아 보내던 호출은 그 값이 이제 적용된다는 점을 확인하세요. 바꿀 생각이 없다면 빼고 보내세요.

**하위 호환 불가 — recovery 수정 · 조회 정정**

- `PUT /recoveries/:identifier` — ID 로 지정해도 요청의 `center` 와 작업이 속한 center 를 대조합니다(backup 과 같은 방식). 다르면 **404 `JOB-ERROR-01`** 입니다. 종전에는 다른 center 의 작업이 그대로 수정됐습니다. 작업이 속한 center 는 `GET /recoveries/:identifier` 로 확인하세요.
- `PUT /recoveries/:identifier` — 이름 변경 중 예기치 않은 오류가 나면 종전의 404 `JOB-ERROR-08` 대신 **500 `INTERNAL_SERVER_ERROR`** 를 반환합니다. 같은 이름이 이미 있을 때의 409 는 그대로입니다. `JOB-ERROR-08` 을 "대상 없음"으로 처리하던 코드는 500 을 서버 오류로 처리하세요.
- `GET /recoveries` · `GET /recoveries/:identifier` — 복구 대상 파티션을 찾지 못하면 `job.detail[].to` 가 원본 드라이브 대신 `"Unknown"` 입니다. 원본 드라이브는 `from` 을 읽으세요.
- `GET /recoveries` — `sort` 를 이제 작업 시작 시각 기준으로 적용합니다. 생략하면 `desc` 입니다. 아직 시작하지 않은 작업은 `asc` 에서 맨 앞, `desc` 에서 맨 뒤에 옵니다. `sort` 를 보내지 않아도 목록 순서와 페이지 경계가 종전과 달라지므로, 필요한 순서는 `sort` 로 명시하세요.

**하위 호환 불가 — cloud-auth 조회 응답에서 자격증명과 서버 경로 제거**

- `GET /cloud-auth/recovery` — AWS 항목의 `accessKey` · `secretKey`, GCP 항목의 `serviceAccount` · `serviceKeyFilePath` 를 응답에서 뺐습니다. 등록한 자격증명이 조회 응답에 평문으로 실려 나가던 문제입니다. GCP 키 파일 이름은 `serviceKeyFile` 로 계속 나갑니다.
- `GET /cloud-auth/zos` 항목과 ZOS 등록 응답의 `cloudInfo` 에서 서버 저장 경로 `filePath` 를 뺐습니다. 파일 이름은 `fileName` 으로 계속 나갑니다.
- 등록 요청 방식과 ZOS 파일 내려받기(`GET /cloud-auth/zos/download/:fileName`)는 그대로입니다.
- 대응: 이 필드를 읽던 코드는 `fileName` · `serviceKeyFile` 을 사용하세요. 자격증명이 필요하면 등록한 쪽에서 따로 보관하세요.

**하위 호환 불가 — 숫자 schedule ID 의 center 소속 · type 검사**

- 대상: backup · recovery · replication(V1 · V2) · os-replication 의 등록 · 수정 (`POST` · `PUT`)에서 `schedule` 에 기존 스케줄 ID(숫자)를 지정하는 요청.
- 지정한 스케줄이 작업의 center 에 속하지 않으면 **403 `CENTER-ERROR-01`** 입니다(`Schedule ID '<id>' does not belong to center <center>`). 기준은 등록이면 요청 `center`, 수정이면 작업이 속한 center 이며 `nCenterID = 0` 도 하나의 center 로 비교합니다. 종전에는 다른 center 의 스케줄도 붙었습니다.
- recovery · replication · os-replication 은 Smart 스케줄(type 7~11) ID 를 400 으로 거부합니다. recovery 는 등록 · 수정 모두 `JOB-ERROR-101`, replication · os-replication 은 등록 `JOB-ERROR-103` · 수정 `JOB-ERROR-101` 입니다. 객체로 보낼 때와 같은 코드입니다.
- 검사 순서는 존재(404 `SCHEDULE-ERROR-01`) → center(403) → type(400)입니다.
- 대응: 숫자 schedule ID 는 작업과 같은 center 의 스케줄을 지정하세요(`GET /schedules` 로 center 확인). recovery · replication · os-replication 에는 type 0~6 스케줄만 지정하세요.

**하위 호환 불가 — backup 의 숫자 schedule ID 는 full/increment 전용**

- 대상: `POST /backups` · `PUT /backups/:identifier` 의 최상위 `schedule: <숫자>`.
- 판정 mode 는 등록이면 요청 `mode`, 수정이면 요청 `mode`(없으면 기존 작업 mode)입니다.
  - smart mode 에 숫자 ID → **400 `JOB-ERROR-102`** (`Smart job mode cannot use a single schedule ID. Use the object form { type, basic: <id>, advanced: <id> }.`). 수정에서 Smart 작업에 type 0~6 행 ID 를 주면 종전에는 200 이었고 "Smart + type 0~6 basic" 상태가 저장됐습니다.
  - full/increment mode 에 Smart 스케줄 행(type 7~11) ID → **400 `JOB-ERROR-101`** (`Schedule ID '<id>' is a smart schedule (type N). Full/increment job modes accept schedule type 0-6 only.`). 종전에는 500 이었습니다.
- 객체 형식에서 Smart 스케줄의 `basic` 이나 `advanced` 가 빠지면 종전의 500 대신 **400 `JOB-ERROR-102`** (`Smart job mode requires both a basic and an advanced schedule.`)입니다. 수정에서 Full 작업에 type 7 이상 객체를 보내 Smart 로 자동 전환되는 경우도 같습니다.
- 모드-스케줄 자동 전환(Smart → Full 등)은 객체로 보낼 때만 적용됩니다. 숫자 ID 는 전환되지 않습니다.
- 대응: Smart 작업을 단일 basic 스케줄로 바꾸려면 숫자 ID 와 함께 `mode: "full"`(또는 `"increment"`)을 보내세요. 이때 advanced 는 0 으로 초기화됩니다. Smart 를 유지하거나 Smart 스케줄을 ID 로 지정하려면 `{ "type": 7, "basic": <ID>, "advanced": <ID> }` 형식으로 두 자리를 함께 보내세요.

**하위 호환 불가 — 객체 형식 schedule 안의 숫자 ID 검사**

- 대상: backup · recovery · replication(V1 · V2) · os-replication 등록 · 수정의 `schedule: { type, basic: <숫자>, advanced?: <숫자> }`.
- 종전에는 존재와 Smart 자리만 확인해 요청 `type` 과 다른 type 의 행도, 다른 center 의 행도 복사됐습니다. backup 에서 `basic` 자리에 Smart 행(type 7 이상)을 가리키고 요청 `type` 이 0~6 이면 500 이었습니다.
- 이제 다른 center 의 행은 **403 `CENTER-ERROR-01`**, 행 type 이 요청 `type` 과 다르면 **400 `JOB-ERROR-108`** (`Schedule ID '<id>' is type <n>, but the request type is <m>.`)입니다. `basic` · `advanced` 모두 해당하며 순서는 존재(404) → center(403) → type(400) → Smart 자리(400 `JOB-ERROR-108`)입니다.
- 최상위 숫자 ID 와 숫자가 없는 객체 형식은 영향이 없습니다.
- 대응: 객체에 숫자 ID 를 넣을 때는 요청 `type` 을 참조 행의 type 과 같게 하고(`GET /schedules/<id>` 의 `type`), 작업과 같은 center 의 스케줄만 지정하세요.

**하위 호환 불가 — recovery 등록의 이미지 조회 시간 초과 응답 408 → 500 `JOB-ERROR-68`**

- 대상: `POST /recoveries` · `POST /recoveries/image`.
- 데몬이 이미지 목록을 채우지 못하면 종전에는 바깥 대기 한도가 안쪽 폴링 예산과 같아 바깥이 먼저 끝나 408 `TIMEOUT_ERROR` 가 나가 원인이 가려졌습니다. 이제 **500 `JOB-ERROR-68`** (`Backup image lookup timed out …`, center · repository · 마지막 작업 상태 포함)입니다.
- 이미지 조회 대기는 (center, repository) 조합마다 30초이고, 서버 바깥 한도는 대기 합계 + 25초입니다. 조합이 1 · 2 · 3 · 4개이면 기본 폴링 간격(1초)에서 55 · 85 · 115 · 145초입니다(종전 30 · 60 · 90 · 120초). 최악 응답 시간이 25초 늘어납니다. 정상 경로는 변화 없습니다.
- 대응: 클라이언트의 요청 timeout 을 서버 바깥 한도보다 길게 두세요(조합 1개 기준 55초 이상). 408 로 시간 초과를 판정하던 코드는 `JOB-ERROR-68` 도 재시도할 수 있는 이미지 조회 실패로 처리하세요.

**하위 호환 불가 — recovery 모니터링 · 수정 응답의 작업 ID 를 `nID` 로 통일**

- 대상: `GET /recoveries/monitoring/job/:identifier` 의 `job.info.id`, `PUT /recoveries/:identifier` 응답의 `jobInfo.id`.
- 종전에는 `job_recovery.nJobID` 를 내보냈습니다. 이 값은 작업 행 `nID` 의 사본이라 비어 있거나 다르면 `null`(수정은 `"null"`)이 나가거나 모니터링이 500 `JOB-ERROR-16` 또는 빈 진행 · 파티션으로 응답했습니다. 이제 작업 행 `nID` 이며 목록 · 조회의 작업 ID 와 같은 값입니다. 두 값이 같았던 작업은 응답이 그대로입니다. 작업 정보가 정말 없을 때의 500 `JOB-ERROR-16` 은 그대로이고, 이력 응답의 작업 ID 도 그대로입니다.
- 대응: 이 `id` 를 `nJobID` 로 여겨 다른 조회에 쓰던 코드는 작업 ID(`nID`)로 쓰세요.

---

**Bugfix — backup 등록 · 수정에서 기존 schedule ID 지정 시 실패**

- `POST /backups` · `PUT /backups/:identifier` — 기존 schedule ID(숫자)를 지정하면 모든 파티션이 `Duplicate data exists` 로 실패하던 문제를 고쳤습니다. 요청 · 응답 형식은 같습니다. 숫자 ID 의 mode · center 검사는 위 "backup 의 숫자 schedule ID 는 full/increment 전용" 항목을 참조하세요.

**Bugfix — recovery 수정 · 삭제**

- `PUT /recoveries/:identifier` — 숫자 schedule ID 를 지정하면 응답은 변경됐다고 하지만 실제 schedule 은 그대로이던 문제를 고쳤습니다.
- `PUT /recoveries/:identifier` — 수정할 때 요청과 관계없는 값까지 다시 써서, 그 사이 바뀐 작업 상태가 되돌아갈 수 있던 문제를 고쳤습니다. 요청한 항목만 저장합니다.
- `DELETE /recoveries/:identifier` — ID 로 삭제할 때 `center` 를 주지 않으면 다른 center 에 있는 같은 이름 작업의 이력 · 로그까지 지워지던 문제를 고쳤습니다. 응답 형식은 같습니다.
- `DELETE /recoveries/:identifier` — 응답 `jobInfo[].partition` 에 같은 파티션이 반복 표기되던 문제(`"/boot, /boot"`)를 고쳤습니다.
- `POST /recoveries` · `POST /recoveries/image` — 모니터링 `details[].diskNumber`(Windows)가 복구 대상이 아닌 원본 디스크 번호를 보이던 문제를 고쳤습니다. 새로 등록한 작업부터 적용되며, 이미 등록된 작업의 값은 그대로입니다.
- `GET /recoveries` — 서버 정보가 다른 center 의 같은 이름 서버로 채워질 수 있던 문제를 고쳤습니다.

**Bugfix — 같은 이름 · 같은 키의 동시 요청**

- backup · recovery 등록과 이름 변경에서, 다른 center 의 같은 이름 요청이 동시에 들어와도 차례로 처리해 같은 이름 작업이 두 건 생기지 않습니다. 기다림이 길어지면 **409 `CONFLICT`** 가 나갈 수 있습니다.
- backup · recovery 수정에서 현재 이름과 같은 `changeName` 을 보내면 종전의 409 `JOB-ERROR-07` 대신 200 으로 성공합니다. 다른 작업이 쓰는 이름은 그대로 409 입니다.
- `POST /licenses` — 같은 키를 동시에 등록해도 한 건만 등록됩니다. 뒤 요청은 409 `LICENSE-ERROR-11`, 기다림이 길어지면 409 `CONFLICT` 입니다.

**Bugfix — 수정 요청의 대문자 값 거부**

- backup · recovery · replication · os-replication 수정 body 의 선택형 값(`"START"` · `"OCI"` 등)을 대문자로 보내면 400 이던 문제를 고쳤습니다. 조회 파라미터처럼 대소문자를 구분하지 않습니다.

**Bugfix — cloud-auth**

- `GET /cloud-auth/recovery?cloudType=aws` (또는 `gcp`) 가 등록된 항목이 있어도 늘 0건이던 문제를 고쳤습니다.
- `GET /cloud-auth/recovery` · `GET /cloud-auth/zos` 를 필터 없이 조회해도 최신 등록순으로 정렬합니다.
- `DELETE /cloud-auth/zos/:identifier` — 파일 이름으로 지울 때 같은 이름의 항목이 여럿이면 임의의 한 건을 지우던 동작을, 아무것도 지우지 않고 **409 `CONFLICT`** 로 바꿨습니다. 메시지에 해당 ID 가 나열되니 ID 로 다시 삭제하세요. 한 건이면 종전처럼 삭제합니다.
- `DELETE /cloud-auth/zos/:identifier` — `center` 를 주면 그 center 안에서만 파일 이름을 찾습니다. 다른 center 에 같은 이름이 있어도 삭제할 수 있고, 다른 center 에만 있는 이름이면 404 입니다.

**Bugfix — 시각 · 진행률 표시**

- 응답의 시각 필드가 빈 값 · zero-date(`0000-00-00 00:00:00`) · 읽을 수 없는 값이면 `"1899-11-30 00:00:00"` 또는 `"Invalid Date"` 로 나가던 문제를 고쳐 `"-"` 로 냅니다. backup · recovery · replication · os-replication 조회 · 모니터링과 schedule 응답의 시각 필드가 해당합니다. 작업 로그(`job.log`)의 시각만은 데몬이 남긴 원문 그대로입니다. 정상 값의 표기는 그대로입니다.
- replication · os-replication · backup(작업 기준 · 서버 기준) 모니터링에서 진행률이 비어 있으면 `"null%"` 로 나가던 문제를 고쳐 `"-"` 로 냅니다(recovery 와 같은 규칙).
- backup 서버 기준 모니터링의 `summary.overallProgress` 가 빈 진행률을 0 으로 더하면서 개수에는 넣어 평균이 낮게 나오던 문제를 고쳤습니다. 진행률이 있는 작업만으로 평균을 내고, 모두 비어 있으면 `"-"` 입니다. 예: 40 · 80 · 빈 값이면 `"40%"` → `"60%"`, 모두 빈 값이면 `"0%"` → `"-"`.

**Bugfix — recovery 수정의 변경 내역**

- `PUT /recoveries/:identifier` — 같은 mode 를 보내도 `Recovery Mode` 가 바뀐 것으로 나오던 문제를 고쳤습니다. 저장된 값은 문자열이고 요청 값은 숫자여서 항상 변경으로 판정했습니다. 이제 같은 mode 를 보내면 `commonUpdatedFields` · `eachUpdatedFields` 에 `Recovery Mode` 항목이 생기지 않습니다.
- mode 를 실제로 바꿀 때 파티션별 변경 내역(`eachUpdatedFields`)의 `Recovery Mode` `previous` 가 `"Unknown"` 으로 나가던 문제를 고쳤습니다. 이제 `"Full Recovery"` · `"Incremental Recovery"` 처럼 실제 이름입니다.

**Bugfix — 스케줄 타입 이름과 `GET /schedules?type=` 필터**

- 작업 등록 · 수정의 inline `schedule.type` 에 타입 이름을 주면 `once` · `every minute` · `hourly` · `daily` · `weekly`(0~4)만 변환되고 나머지 7개(예: `"Monthly on Specific Date"`)는 어떤 표기로도 400 으로 거부되던 문제를 고쳤습니다. 12종 모두 대소문자와 앞뒤 공백에 관계없이 0~11 로 변환됩니다.
- `GET /schedules?type=` 이 대소문자를 구분하고 5~11 이름은 결과가 0건이던 문제를 고쳤습니다. 대소문자와 앞뒤 공백을 무시하고 12종 모두 필터합니다. 숫자 입력, 응답의 `type` 표기, 허용 목록 밖 값의 400 메시지는 그대로입니다.

**동작 변경 — backup 이미지 조회 시간 한도**

- `GET /backups/images` · `GET /backups/images/server/:server` — 한 요청에서 동시에 조회하는 저장소 수와 전체 조회 시간에 상한을 뒀습니다. 시간이 모자라 조회하지 못한 저장소는 응답 `scan.failures[]` 에 `reason: "budget_exhausted"`, `retryable: true` 로 기록됩니다. 응답 필드는 추가 · 제거되지 않았습니다.
- 저장소가 많은 환경에서는 일부 저장소가 결과에서 빠질 수 있습니다. 서버 env `BACKUP_IMAGE_SCAN_CONCURRENCY`(기본 4) · `BACKUP_IMAGE_SCAN_TOTAL_BUDGET_MS`(기본 60000, 밀리초)로 조정할 수 있습니다.

**동작 변경 — backup · recovery 상세 모니터링의 로그는 최근 500줄**

- `GET /backups/monitoring/job/:identifier` · `GET /backups/monitoring/system/:identifier`(서버 기준) · `GET /recoveries/monitoring/job/:identifier` 의 `detail=true` 응답 `log` 는 작업의 가장 최근 로그 500줄 안에서 마지막 줄과 같은 실행분만 오래된 줄부터 싣습니다. 응답 모양은 그대로입니다.
- 한 실행의 로그가 500줄을 넘으면 앞쪽(가장 오래된) 줄이 빠집니다. 500줄 이하인 실행은 종전과 같습니다. 같은 작업의 실행이 엇갈려 기록된 경우 최신 실행은 시작 시각이 아니라 마지막으로 기록된 줄 기준으로 고릅니다.

**동작 변경 — 토큰 발급 횟수 제한 기본값 100 → 2700**

- `POST /token/issue` — IP 별 발급 시도 제한의 기본값을 **15분당 100회에서 2700회**(초당 3회)로 올렸습니다. 서버 env `RATE_LIMIT_TOKEN_MAX` 를 지정했다면 그 값이 우선합니다. 제한을 좁히려면 이 값을 낮추세요.

---

**보안 — 배포 파일의 설정 값**

- 이 버전부터는 배포 파일마다 새로 만든 설정(`env/.env.production`)이 실립니다. `JWT_SECRET` 은 무작위 값이고 `DB_PASSWORD` 는 비어 있습니다.
- 새로 설치: `DB_PASSWORD` 를 채운 뒤 실행하세요. 비어 있으면 서버가 시작되지 않습니다.
- 업그레이드: 기존 env 파일을 그대로 두세요. 덮어쓰면 DB 에 접속하지 못하고, `JWT_SECRET` 이 바뀌어 이미 발급한 토큰을 쓸 수 없게 됩니다.
- `JWT_SECRET` 은 설치마다 고유한 값을 쓰기를 권장합니다.

**설정 — 업로드 파일 저장 경로 기본값 통일**

- 업로드 파일 저장 경로 기본값을 `/ZConverterManager/api-files/uploads` 로 통일했습니다. env 에 `UPLOAD_FILE_SAVE_PATH` 가 있으면 그 값을 그대로 씁니다.
- 새 env 로 옮기는 v3.0.x 설치본은 기존 경로 `/ZConverterManager/api-file` 의 업로드 파일을 새 경로로 옮기세요. 옮기지 않으면 파일 목록 · 다운로드에 나오지 않습니다.

**보안 — 그 밖의 수정**

- 파일 업로드 요청에서 예기치 않은 오류가 나면 오류 원문 대신 다른 요청과 같은 `INTERNAL_SERVER_ERROR` 로 응답합니다. DB 오류의 내부 코드도 응답에 실리지 않습니다.
- cloud-auth 파일 업로드 · 내려받기에서 저장 디렉터리 밖을 가리키는 파일 이름이나 사용자 email 은 **400 `FILE-ERROR-11`** 로 거절합니다. 일반적인 이름은 종전과 같습니다.
- `SQL_LOG_VALUES=true` 로 켰을 때 SQL 디버그 로그에 자격증명 값이 평문으로 남던 문제를 고쳤습니다. 기본 설정(꺼짐)의 로그는 그대로입니다.

**배포 파일 — 릴리스 노트 동봉**

- 배포 파일 최상위에 이 버전의 릴리스 노트 `RELEASE_NOTES.md` 와 버전 번호를 담은 `VERSION` 파일이 들어 있습니다.

운영 개선 — 서버 내부 처리 정리(설정 로드 라이브러리 업데이트, 파일 경로 계산 통일, 이미지 조회 취소 처리 등). 클라이언트 영향 없음.

자세한 내용은 [Replication 조회](/zdm/ko/api/4.0.0/docs/replication/get) · [Replication 수정](/zdm/ko/api/4.0.0/docs/replication/update) · [Recovery 수정](/zdm/ko/api/4.0.0/docs/recovery/update) · [Cloud-auth Recovery 목록](/zdm/ko/api/4.0.0/docs/cloud-auth/recovery-list) · [에러 코드](/zdm/ko/api/4.0.0/docs/error-codes) 참조.
